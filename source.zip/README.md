# 实验二 文档倒排索引算法实现

使用 Java 编写 Hadoop MapReduce 程序，为 10 篇公开英文技术文档建立倒排索引。输入与输出保存在 HDFS，作业提交给单节点 YARN 集群，使用 2 个 Reducer。

## 数据和分词规则

`data/documents/` 保存从 Apache Hadoop 3.4.1 网站下载的 10 篇英文文档。原始链接、下载时间和文件校验值见 `data/sources.json`，第三方文本许可见 `data/NOTICE.txt`。网页正文转换为 UTF-8 文本，去除站点导航、脚本和样式。

分词统一转为小写，以连续的 `[a-z]+` 作为词项，数字和标点作为边界；使用 `data/stopwords.txt` 中的停词表。未做词干提取或词形还原。

## 算法

Mapper 输出 `(单词, 文档名与次数1)`，并过滤停词。Combiner 按同一单词和文档名合并局部词频。Reducer 汇总每篇文档的词频，按文档名排序，最后追加总词频。例如：

```text
data    <document01.txt,6>;<document02.txt,3>;<total,9>.
```

上面仅为格式示例，实际结果由运行生成。完整结果保存为 `results/index.txt`。各分区结果由下载脚本合并并按单词排序。

## 运行

环境：Linux、Java 11、Hadoop 3.4.1、Python 3。下载脚本另外使用 lxml，但仓库中已包含本次下载的文档，运行实验无需重新抓取。

```bash
export JAVA_HOME=/path/to/jdk-11
export HADOOP_HOME=/path/to/hadoop-3.4.1
export LAB_STATE=/tmp/lab2-fresh-state
bash scripts/run_experiment.sh
```

`LAB_STATE` 必须是不存在的新目录。启动脚本只格式化本实验新建的数据目录。运行结束后停止本次启动的 Hadoop 服务。GitHub Actions 中可通过 `Inverted index experiment` 工作流重现实验。

## 检查

`tests/verify.py` 使用独立的 Python Counter 统计全部文档，与每一条 MapReduce 输出比较。同时检查停词过滤、大小写、标点、数字、重复词、空文档、多 Reducer、关闭 Combiner、输出目录冲突和缺少停词文件等情况。运行记录由工作流生成，保存在 `lab2-evidence` 构件中。
