"""Download ten public Apache Hadoop pages and retain their English article text."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen
from urllib.parse import urljoin
from lxml import html
import hashlib, json, re

ROOT = Path(__file__).resolve().parents[1]
INDEX = 'https://hadoop.apache.org/docs/r3.4.1/'
CHOICES = [
    ('Single Node Setup', '单节点环境配置'),
    ('Cluster Setup', '集群配置'),
    ('FileSystem Shell', '文件系统命令'),
    ('Architecture', 'HDFS 架构'),
    ('User Guide', 'HDFS 使用指南'),
    ('Tutorial', 'MapReduce 编程'),
    ('Architecture', 'YARN 架构'),
    ('Capacity Scheduler', '容量调度器'),
    ('Hadoop Streaming', '流式处理接口'),
    ('DistCp', '分布式文件复制'),
]

def fetch(url):
    request = Request(url, headers={'User-Agent': 'Hadoop-Lab2-Educational-Corpus/1.0'})
    with urlopen(request, timeout=60) as response:
        return response.read()

def main():
    corpus = ROOT/'data/documents'
    corpus.mkdir(parents=True, exist_ok=True)
    soup = html.fromstring(fetch(INDEX))
    links = soup.xpath('//a[@href]')
    used = set()
    sources = []
    for index, (label, topic) in enumerate(CHOICES, 1):
        matches = [a for a in links if a.text_content().strip() == label and a.get('href') not in used]
        if not matches:
            raise RuntimeError('Source link missing: '+label)
        link = matches[0].get('href')
        used.add(link)
        sources.append({'file': f'document{index:02d}.txt', 'topic': topic, 'url': urljoin(INDEX, link)})

    def download(item):
        raw = fetch(item['url'])
        page = html.fromstring(raw, parser=html.HTMLParser(remove_comments=True, encoding='utf-8'))
        candidates = page.xpath('//*[@id="contentBox"]')
        if not candidates:
            raise RuntimeError('Article container missing: '+item['url'])
        article = candidates[0]
        title = article.xpath('.//h1|.//h2')[0].text_content().strip()
        for element in article.xpath('.//script|.//style|.//nav|.//*[@class="toc"]|.//*[@class="TOC"]'):
            element.drop_tree()
        lines = [re.sub(r'\s+', ' ', line).strip() for line in '\n'.join(article.itertext()).splitlines()]
        text = '\n'.join(line for line in lines if line)+'\n'
        tokens = re.findall(r'[a-z]+', text.lower())
        if len(tokens) < 100:
            raise RuntimeError('Source is unexpectedly short: '+item['url'])
        data = text.encode('utf-8')
        (corpus/item['file']).write_bytes(data)
        return {**item, 'title': title,
                'downloaded_at': datetime.now(timezone.utc).isoformat(), 'raw_html_sha256': hashlib.sha256(raw).hexdigest(),
                'text_sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'raw_tokens': len(tokens)}

    with ThreadPoolExecutor(max_workers=4) as pool:
        manifest = list(pool.map(download, sources))
    (ROOT/'data/sources.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (ROOT/'data/LICENSE-APACHE-2.0.txt').write_bytes(fetch('https://www.apache.org/licenses/LICENSE-2.0.txt'))
    for item in manifest:
        print(item['file'], item['raw_tokens'], item['title'])
    print('DOCUMENTS', len(manifest), 'RAW_TOKENS', sum(d['raw_tokens'] for d in manifest))

if __name__ == '__main__':
    main()
