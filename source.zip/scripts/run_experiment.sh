#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results build/classes
export HADOOP_CONF_DIR="$LAB_STATE/conf" HADOOP_LOG_DIR="$LAB_STATE/logs" HADOOP_PID_DIR="$LAB_STATE/pids"
export HADOOP_COMMON_HOME="$HADOOP_HOME" HADOOP_HDFS_HOME="$HADOOP_HOME" HADOOP_YARN_HOME="$HADOOP_HOME" HADOOP_MAPRED_HOME="$HADOOP_HOME"
export PATH="$HADOOP_HOME/bin:$PATH"
python3 tests/verify.py prepare
bash scripts/setup_hadoop.sh 2>&1 | tee results/setup.log
cleanup() {
  yarn --daemon stop nodemanager || true
  yarn --daemon stop resourcemanager || true
  hdfs --daemon stop datanode || true
  hdfs --daemon stop namenode || true
}
trap cleanup EXIT
javac -encoding UTF-8 --release 11 -classpath "$(hadoop classpath --glob)" -d build/classes src/lab/InvertedIndex.java
jar cf build/lab2.jar -C build/classes .
echo 'COMPILE PASS build/lab2.jar'
hdfs dfs -mkdir -p /user/runner/lab2/documents /user/runner/lab2/fixture
hdfs dfs -put data/documents/*.txt /user/runner/lab2/documents/
hdfs dfs -put data/stopwords.txt /user/runner/lab2/stopwords.txt
hdfs dfs -put build/fixture/*.txt /user/runner/lab2/fixture/
hdfs dfs -ls /user/runner/lab2/documents | tee results/hdfs-input.txt
echo '=== Corpus MapReduce job on YARN ==='
hadoop jar build/lab2.jar lab.InvertedIndex /user/runner/lab2/documents /user/runner/lab2/index /user/runner/lab2/stopwords.txt results/corpus-job.json 2 2>&1 | tee results/corpus-job.log
hdfs dfs -cat '/user/runner/lab2/index/part-r-*' | LC_ALL=C sort > results/index.txt
echo '=== Boundary fixture without Combiner ==='
hadoop jar build/lab2.jar lab.InvertedIndex /user/runner/lab2/fixture /user/runner/lab2/fixture-index /user/runner/lab2/stopwords.txt results/fixture-job.json 2 --no-combiner 2>&1 | tee results/fixture-job.log
hdfs dfs -cat '/user/runner/lab2/fixture-index/part-r-*' | LC_ALL=C sort > results/fixture-index.txt
echo '=== Refuse an existing output directory ==='
if hadoop jar build/lab2.jar lab.InvertedIndex /user/runner/lab2/documents /user/runner/lab2/index /user/runner/lab2/stopwords.txt results/unexpected.json 2 > results/existing-output.log 2>&1; then
  echo 'ERROR: existing output was accepted'; exit 1
fi
grep -q 'Output already exists' results/existing-output.log
hdfs dfs -cat '/user/runner/lab2/index/part-r-*' | LC_ALL=C sort > results/index-after-rejected-run.txt
cmp results/index.txt results/index-after-rejected-run.txt
echo '=== Refuse a missing stop-word file ==='
if hadoop jar build/lab2.jar lab.InvertedIndex /user/runner/lab2/documents /user/runner/lab2/no-result /user/runner/lab2/missing-stops.txt results/unexpected.json 2 > results/missing-stopwords.log 2>&1; then
  echo 'ERROR: missing stopwords were accepted'; exit 1
fi
grep -q 'Stop-word file does not exist' results/missing-stopwords.log
yarn application -list -appStates FINISHED | tee results/yarn-applications.txt
curl --fail --silent http://localhost:8088/ws/v1/cluster/apps > results/yarn-applications.json
hdfs fsck /user/runner/lab2 | tee results/hdfs-fsck.txt
python3 tests/verify.py verify | tee results/verification.log
{
  uname -a
  cat /etc/os-release
  java -version
  hadoop version
  nproc
  free -h
} > results/environment.txt 2>&1
cp data/sources.json data/stopwords.txt results/
echo '=== Selected inverted index entries ==='
cat results/selected-index.txt
echo '=== All checks passed ==='
