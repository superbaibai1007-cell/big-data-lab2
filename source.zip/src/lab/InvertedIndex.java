package lab;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.JobCounter;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/** A one-job inverted index: term -> sorted (document, frequency) postings. */
public class InvertedIndex extends Configured implements Tool {
    public enum Tokens { RAW, STOPPED, KEPT }

    public static class DocCount implements Writable {
        private final Text document = new Text();
        private long count;
        public DocCount() { }
        public DocCount(String document, long count) {
            this.document.set(document);
            this.count = count;
        }
        public String document() { return document.toString(); }
        public long count() { return count; }
        @Override public void write(DataOutput out) throws IOException {
            document.write(out);
            out.writeLong(count);
        }
        @Override public void readFields(DataInput in) throws IOException {
            document.readFields(in);
            count = in.readLong();
        }
    }

    public static class IndexMapper extends Mapper<LongWritable, Text, Text, DocCount> {
        private static final Pattern WORD = Pattern.compile("[a-z]+");
        private final Set<String> stopwords = new HashSet<>();
        private String document;
        @Override protected void setup(Context context) throws IOException {
            document = ((FileSplit) context.getInputSplit()).getPath().getName();
            if (!document.matches("[A-Za-z0-9._-]+")) {
                throw new IOException("Use a plain filename without posting delimiters: " + document);
            }
            for (String line : Files.readAllLines(Paths.get("stopwords.txt"), StandardCharsets.UTF_8)) {
                String word = line.trim().toLowerCase(Locale.ROOT);
                if (!word.isEmpty()) stopwords.add(word);
            }
        }
        @Override protected void map(LongWritable offset, Text line, Context context)
                throws IOException, InterruptedException {
            Matcher matcher = WORD.matcher(line.toString().toLowerCase(Locale.ROOT));
            while (matcher.find()) {
                String word = matcher.group();
                context.getCounter(Tokens.RAW).increment(1);
                if (stopwords.contains(word)) {
                    context.getCounter(Tokens.STOPPED).increment(1);
                    continue;
                }
                context.write(new Text(word), new DocCount(document, 1));
                context.getCounter(Tokens.KEPT).increment(1);
            }
        }
    }

    public static class IndexCombiner extends Reducer<Text, DocCount, Text, DocCount> {
        @Override protected void reduce(Text word, Iterable<DocCount> values, Context context)
                throws IOException, InterruptedException {
            Map<String, Long> counts = new HashMap<>();
            // Hadoop reuses value objects, so retain copied names and primitive counts.
            for (DocCount value : values) counts.merge(value.document(), value.count(), Math::addExact);
            for (Map.Entry<String, Long> entry : counts.entrySet()) {
                context.write(word, new DocCount(entry.getKey(), entry.getValue()));
            }
        }
    }

    public static class IndexReducer extends Reducer<Text, DocCount, Text, Text> {
        @Override protected void reduce(Text word, Iterable<DocCount> values, Context context)
                throws IOException, InterruptedException {
            Map<String, Long> counts = new TreeMap<>();
            for (DocCount value : values) counts.merge(value.document(), value.count(), Math::addExact);
            StringBuilder postings = new StringBuilder();
            long total = 0;
            for (Map.Entry<String, Long> entry : counts.entrySet()) {
                postings.append('<').append(entry.getKey()).append(',').append(entry.getValue()).append(">;");
                total = Math.addExact(total, entry.getValue());
            }
            postings.append("<total,").append(total).append(">.");
            context.write(word, new Text(postings.toString()));
        }
    }

    @Override public int run(String[] args) throws Exception {
        if (args.length < 4 || args.length > 6) {
            System.err.println("Usage: InvertedIndex input output stopwordsURI localMetadata.json [reducers] [--no-combiner]");
            return 2;
        }
        int reducers = args.length >= 5 ? Integer.parseInt(args[4]) : 2;
        if (reducers < 1) throw new IllegalArgumentException("At least one reducer is required");
        boolean combine = args.length < 6 || !args[5].equals("--no-combiner");
        if (args.length == 6 && combine) throw new IllegalArgumentException("Unknown option: " + args[5]);
        Path input = new Path(args[0]);
        Path output = new Path(args[1]);
        Path stops = new Path(args[2]);
        if (!input.getFileSystem(getConf()).exists(input)) throw new IOException("Input does not exist: " + input);
        if (output.getFileSystem(getConf()).exists(output)) throw new IOException("Output already exists: " + output);
        FileSystem stopFS = stops.getFileSystem(getConf());
        if (!stopFS.isFile(stops)) throw new IOException("Stop-word file does not exist: " + stops);
        URI stopURI = stopFS.makeQualified(stops).toUri();
        Job job = Job.getInstance(getConf(), "lab2-inverted-index" + (combine ? "" : "-no-combiner"));
        job.setJarByClass(InvertedIndex.class);
        job.setMapperClass(IndexMapper.class);
        if (combine) job.setCombinerClass(IndexCombiner.class);
        job.setReducerClass(IndexReducer.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DocCount.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        job.setNumReduceTasks(reducers);
        job.addCacheFile(new URI(stopURI.toString() + "#stopwords.txt"));
        FileInputFormat.addInputPath(job, input);
        FileOutputFormat.setOutputPath(job, output);
        if (!job.waitForCompletion(true)) return 1;
        String metadata = String.format(Locale.ROOT,
            "{\n  \"job_id\": \"%s\",\n  \"framework\": \"%s\",\n  \"combiner\": %s,\n  \"reducers\": %d,\n  \"maps_launched\": %d,\n  \"reduces_launched\": %d,\n  \"raw_tokens\": %d,\n  \"stopped_tokens\": %d,\n  \"kept_tokens\": %d\n}\n",
            job.getJobID(), getConf().get("mapreduce.framework.name", "local"), combine, reducers,
            job.getCounters().findCounter(JobCounter.TOTAL_LAUNCHED_MAPS).getValue(),
            job.getCounters().findCounter(JobCounter.TOTAL_LAUNCHED_REDUCES).getValue(),
            job.getCounters().findCounter(Tokens.RAW).getValue(),
            job.getCounters().findCounter(Tokens.STOPPED).getValue(),
            job.getCounters().findCounter(Tokens.KEPT).getValue());
        Files.write(Paths.get(args[3]), metadata.getBytes(StandardCharsets.UTF_8));
        System.out.println(metadata);
        return 0;
    }
    public static void main(String[] args) throws Exception {
        System.exit(ToolRunner.run(new InvertedIndex(), args));
    }
}
