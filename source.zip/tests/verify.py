"""Independent Python oracle and end-to-end checks for the Hadoop output."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT/'results'
STOPS = set((ROOT/'data/stopwords.txt').read_text(encoding='utf-8').split())
WORD = re.compile(r'[a-z]+')

def reference(directory):
    index = defaultdict(dict)
    statistics = []
    for path in sorted(directory.glob('*.txt')):
        raw = WORD.findall(path.read_text(encoding='utf-8').lower())
        counts = Counter(word for word in raw if word not in STOPS)
        for word, count in counts.items():
            index[word][path.name] = count
        statistics.append({'file': path.name, 'raw_tokens': len(raw), 'kept_tokens': sum(counts.values()),
                           'unique_terms': len(counts)})
    return dict(index), statistics

def prepare():
    RESULTS.mkdir(exist_ok=True)
    sources = json.loads((ROOT/'data/sources.json').read_text(encoding='utf-8'))
    assert len(sources) >= 10
    assert len({item['url'] for item in sources}) == len(sources)
    assert {item['file'] for item in sources} == {p.name for p in (ROOT/'data/documents').glob('*.txt')}
    for item in sources:
        content = (ROOT/'data/documents'/item['file']).read_bytes()
        assert hashlib.sha256(content).hexdigest() == item['text_sha256'], item['file']
    assert {'a', 'an', 'the'} <= STOPS
    assert all(re.fullmatch('[a-z]+', word) for word in STOPS)
    fixture = ROOT/'build/fixture'
    fixture.mkdir(parents=True, exist_ok=True)
    examples = {
        'docA.txt': 'Data, DATA! data; Hadoop.\nThe and a are of.\nindex index 42\n',
        'docB.txt': 'hadoop data Search SEARCH!\nIndex; x-ray 123 C++\n',
        'docC.txt': '',
        'docD.txt': 'a an the AND OF is to\n',
    }
    for name, text in examples.items():
        (fixture/name).write_text(text, encoding='utf-8')
    index, statistics = reference(ROOT/'data/documents')
    summary = {'documents': len(sources), 'stopwords': len(STOPS), 'terms': len(index),
               'raw_tokens': sum(s['raw_tokens'] for s in statistics),
               'kept_tokens': sum(s['kept_tokens'] for s in statistics), 'per_document': statistics}
    summary['removed_tokens'] = summary['raw_tokens'] - summary['kept_tokens']
    (RESULTS/'corpus-stats.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print('CORPUS CHECKSUMS AND FIXTURE PREPARED')

def parse(path):
    index = {}
    terms = []
    for line in path.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([a-z]+)\t((?:<[A-Za-z0-9._-]+,[1-9][0-9]*>;)+)<total,([1-9][0-9]*)>\.', line)
        assert match, 'Invalid result format: '+line
        word, body, total = match.groups()
        pairs = [(doc, int(count)) for doc, count in re.findall(r'<([^,]+),([0-9]+)>;', body)]
        assert len(pairs) == len(dict(pairs)), 'Duplicate document: '+word
        assert pairs == sorted(pairs), 'Unsorted postings: '+word
        assert sum(count for _, count in pairs) == int(total), 'Wrong total: '+word
        assert word not in index, 'Duplicate term: '+word
        index[word] = dict(pairs)
        terms.append(word)
    assert terms == sorted(terms), 'Merged result must be sorted'
    return index

def verify():
    checks = []
    def check(name, condition):
        assert condition, name
        checks.append(name)
        print('PASS', name)
    corpus, statistics = reference(ROOT/'data/documents')
    actual = parse(RESULTS/'index.txt')
    check('Every corpus posting and count matches independent Python Counter', actual == corpus)
    check('All stop words are absent from the inverted index', not STOPS.intersection(actual))
    check('All ten input documents occur in the corpus postings',
          {doc for postings in actual.values() for doc in postings} == {item['file'] for item in statistics})
    check('Output grammar, per-document ordering, unique postings and totals', bool(actual))
    job = json.loads((RESULTS/'corpus-job.json').read_text())
    check('Corpus job used YARN and two reducers', job['framework'] == 'yarn' and job['reducers'] == 2)
    check('Corpus job launched ten map tasks and two reduce tasks', job['maps_launched'] == 10 and job['reduces_launched'] == 2)
    check('Corpus job enabled Combiner', job['combiner'] is True)
    check('Raw token counter matches all documents', job['raw_tokens'] == sum(s['raw_tokens'] for s in statistics))
    kept = sum(sum(postings.values()) for postings in corpus.values())
    check('Kept token counter equals the sum of all posting counts', job['kept_tokens'] == kept)
    check('Removed token counter balances the input count', job['raw_tokens'] == job['kept_tokens'] + job['stopped_tokens'])
    expected_fixture = {
        'data': {'docA.txt': 3, 'docB.txt': 1}, 'hadoop': {'docA.txt': 1, 'docB.txt': 1},
        'index': {'docA.txt': 2, 'docB.txt': 1}, 'search': {'docB.txt': 2},
        'x': {'docB.txt': 1}, 'ray': {'docB.txt': 1}, 'c': {'docB.txt': 1},
    }
    fixture = parse(RESULTS/'fixture-index.txt')
    check('Known fixture handles case, punctuation, numbers and repeats', fixture == expected_fixture)
    check('Empty and stop-word-only documents contribute no postings',
          not {'docC.txt', 'docD.txt'}.intersection({d for v in fixture.values() for d in v}))
    fixture_job = json.loads((RESULTS/'fixture-job.json').read_text())
    check('Fixture is correct with Combiner disabled', fixture_job['combiner'] is False)
    check('Fixture also used YARN and two reducers', fixture_job['framework'] == 'yarn' and fixture_job['reducers'] == 2)
    check('Existing output is rejected without changing prior results',
          'Output already exists' in (RESULTS/'existing-output.log').read_text() and
          (RESULTS/'index.txt').read_bytes() == (RESULTS/'index-after-rejected-run.txt').read_bytes())
    check('Missing stop-word file fails before job submission',
          'Stop-word file does not exist' in (RESULTS/'missing-stopwords.log').read_text())
    apps = json.loads((RESULTS/'yarn-applications.json').read_text())['apps']['app']
    status = {app['id']: app['finalStatus'] for app in apps}
    check('ResourceManager recorded both applications as SUCCEEDED',
          all(status.get(j['job_id'].replace('job_', 'application_')) == 'SUCCEEDED' for j in [job, fixture_job]))
    check('HDFS filesystem check is healthy', 'Status: HEALTHY' in (RESULTS/'hdfs-fsck.txt').read_text())
    selected = ['data', 'hadoop', 'index', 'mapreduce', 'search']
    rows = (RESULTS/'index.txt').read_text(encoding='utf-8').splitlines()
    selected_rows = [line for term in selected for line in rows if line.startswith(term+'\t')]
    check('All five required example terms have observed results', len(selected_rows) == 5)
    (RESULTS/'selected-index.txt').write_text('\n'.join(selected_rows)+'\n', encoding='utf-8')
    summary = {'passed_checks': len(checks), 'checks': checks, 'unique_terms': len(actual),
               'documents': len(statistics), 'raw_tokens': job['raw_tokens'], 'kept_tokens': kept,
               'stopped_tokens': job['stopped_tokens'], 'stopwords': len(STOPS),
               'applications': status, 'selected_postings': {word: actual[word] for word in selected}}
    (RESULTS/'verification.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print('VERIFICATION PASSED:', len(checks), 'checks;', len(actual), 'unique terms;', kept, 'indexed tokens')

if __name__ == '__main__':
    {'prepare': prepare, 'verify': verify}[sys.argv[1]]()
